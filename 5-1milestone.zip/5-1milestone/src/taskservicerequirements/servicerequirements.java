package taskservicerequirements;
import java.util.*;
import taskclassrequirements.*;

public class servicerequirements {
	
	private final Map<String, classrequirements> contacts;
	
	public servicerequirements() {
		this.contacts = new HashMap<String, classrequirements>();
	}

	public boolean addContact(classrequirements contact) {
		boolean isSuccess = false;
		
		if(!contacts.containsKey(contact.getId())) {
			contacts.put(contact.getId(), contact);
			isSuccess = true;
		}
		
		return isSuccess;
	}
	
	public boolean deleteContact(String contactId) {
		return contacts.remove(contactId) != null;
	}
	
	public classrequirements getContact(String contactId) {
		return contacts.get(contactId);
	}
	
	public boolean setApptDate(String contactId, Date date) {
		return this.getContact(contactId).setDate(date);
	}
	
	public boolean setContactDescription(String contactId, String description) {
		return this.getContact(contactId).setdescription(description);
	}

    }