package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import taskclassrequirements.classrequirements;
import taskservicerequirements.servicerequirements;

class servicerequirementsTest {

	@Test
	void testserviceClassAddContact() {
		Date date = new Date(56789456789L * 1000);
		servicerequirements serviceRequirements = new servicerequirements();
		classrequirements classrequirements1 = new classrequirements("11111", date, "descriptiondescriptiondescription");
		classrequirements classrequirements2 = new classrequirements("44444", date, "descriptiondescriptiondescription");
		serviceRequirements.addContact(classrequirements1);
		serviceRequirements.addContact(classrequirements2);
		serviceRequirements.setApptDate("11111", date);
		serviceRequirements.setContactDescription("44444", "Description");
		serviceRequirements.deleteContact("11111");
		serviceRequirements.deleteContact("00000");
	}

}