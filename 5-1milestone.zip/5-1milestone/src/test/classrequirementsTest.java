package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskclassrequirements.classrequirements;
import taskservicerequirements.servicerequirements;
import java.util.Date;

class classrequirementsTest {

	@Test
	void testclassrequirements() {

		Date date = new Date(56789456789L * 1000);
		classrequirements classRequirements = new classrequirements("12345", date, "descriptiondescriptiondescription");
		assertTrue(classRequirements.getId().equals("12345"));
		assertTrue(classRequirements.getDate().equals(date));
		assertTrue(classRequirements.getDescription().equals("descriptiondescriptiondescription"));
	}


	@Test
	void testserviceRequirementsAddContact() {
		Date date = new Date(56789456789L * 1000);
		servicerequirements serviceRequirements = new servicerequirements();
		classrequirements classrequirements1 = new classrequirements("12345", date, "descriptiondescriptiondescription");
		classrequirements classrequirements2 = new classrequirements("11111", date, "descriptiondescriptiondescription");
		serviceRequirements.addContact(classrequirements1);
		serviceRequirements.addContact(classrequirements2);
		serviceRequirements.setApptDate("11111", date);
		serviceRequirements.setContactDescription("11111", "descriptiondescriptiondescription");
	}
	
	@Test
	void testclassrequirementsIdTooLong() {
		Date date = new Date(56789456789L * 1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new classrequirements("123456789000", date, "descriptiondescriptiondescription");
		  });
		}

	@Test
	void testclassrequirementsIdNull() {
		Date date = new Date(56789456789L * 1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new classrequirements(null, date, "descriptiondescriptiondescription");
		  });
		}

	@Test
	void testclassrequirementsDateInPast() {
		Date date = new Date(5678945L * 1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new classrequirements("12345", date, "descriptiondescriptiondescription");
		  });
		}
	
	@Test
	void testclassrequirementsDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new classrequirements("12345", null, "descriptiondescriptiondescription");
		  });
		}
	
	@Test
	void testclassrequirementsDescriptionTooLong() {
		Date date = new Date(56789456789L * 1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new classrequirements("12345", date, "descriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescription");
		  });
		}
	
	@Test
	void testclassrequirementsDescriptionNull() {
		Date date = new Date(56789456789L * 1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new classrequirements("12345", date, null);
		  });
		}
	
	@Test
	void testAddDateInPast() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		Date date = new Date(5678945L * 1000);
		servicerequirements serviceRequirements = new servicerequirements();
		classrequirements classrequirements1 = new classrequirements("11111", date, "descriptiondescriptiondescription");
		serviceRequirements.addContact(classrequirements1);
		serviceRequirements.setApptDate("11111", date);	
		 });
	}
	
	@Test
	void testAddDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Date date = new Date(56789456789L * 1000);
		servicerequirements serviceRequirements = new servicerequirements();
		classrequirements classrequirements1 = new classrequirements("11111", date, "descriptiondescriptiondescription");
		serviceRequirements.addContact(classrequirements1);
		serviceRequirements.setApptDate("11111", null);	
		 });
	}


	
	@Test
	void testAddDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Date date = new Date(56789456789L * 1000);
		servicerequirements serviceRequirements = new servicerequirements();
		classrequirements classrequirements1 = new classrequirements("11111", date, "descriptiondescriptiondescription");
		serviceRequirements.addContact(classrequirements1);
		serviceRequirements.setContactDescription("11111", "descriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescription");	
		 });
	}
	
	@Test
	void testAddDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Date date = new Date(56789456789L * 1000);
		servicerequirements serviceRequirements = new servicerequirements();
		classrequirements classrequirements1 = new classrequirements("11111", date, "descriptiondescriptiondescription");
		serviceRequirements.addContact(classrequirements1);
		serviceRequirements.setContactDescription("11111", null);	
		 });
	}
}
