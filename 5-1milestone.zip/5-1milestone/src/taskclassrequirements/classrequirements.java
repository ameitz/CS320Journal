package taskclassrequirements;
import java.util.Date;
public class classrequirements {


		private String id;
		private Date date;
		private String description;		
		
		public classrequirements(String id, Date newDate, String description) {
		
			if(id == null || id.length()>10) {
				throw new IllegalArgumentException("Invalid id");
			}
			if(newDate == null || newDate.before(new Date())) {
				throw new IllegalArgumentException("Invalid date");
			}
			if(description == null || description.length()>50) {
				throw new IllegalArgumentException("Invalid description");
			}
			
		
			this.id = id;
			this.date = newDate;
			this.description = description;
		}
		
		public Date getDate() {
			return date;
		}
		
		public String getId() {
			return id;
		}
		public String getDescription() {
			return description;
		}

		
		 public Boolean setDate(Date newDate) {
			 if(newDate == null || newDate.before(new Date())) {
				throw new IllegalArgumentException("Invalid date");
			}
			else {
				this.date = newDate;
				return true;
			}
		}
		
		public Boolean setdescription(String description) {
			if(description == null || description.length()>50) {
				throw new IllegalArgumentException("Invalid description");
			}
			else {
				this.description = description;
				return true;
			}
		}}
		