package taskservice;
import java.util.*;
import taskclass.*;

public class tService {
	
	private final Map<String, tClass> contacts;
	
	public tService() {
		this.contacts = new HashMap<String, tClass>();
	}

	public boolean addContact(tClass contact) {
		boolean isSuccess = false;
		
		if(!contacts.containsKey(contact.getId())) {
			contacts.put(contact.getId(), contact);
			isSuccess = true;
		}
		
		return isSuccess;
	}
	
	public boolean deleteContact(String contactId) {
		return contacts.remove(contactId) != null;
	}
	
	public tClass getContact(String contactId) {
		return contacts.get(contactId);
	}
	
	public boolean setContactName(String contactId, String name) {
		return this.getContact(contactId).setName(name);
	}
	
	public boolean setContactDescription(String contactId, String description) {
		return this.getContact(contactId).setdescription(description);
	}

}