package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import taskclass.tClass;
import taskservice.tService;

class tServiceTest {
	
	@Test
	void testserviceClassAddContact() {
		tService TService = new tService();
		tClass TClass1 = new tClass("Alexandra", "11111", "descriptiondescriptiondescription");
		tClass TClass2 = new tClass("Alexandra", "44444", "descriptiondescriptiondescription");
		TService.addContact(TClass1);
		TService.addContact(TClass2);
		TService.setContactName("11111", "Chris");
		TService.setContactDescription("44444", "Description");
		TService.deleteContact("11111");
		TService.deleteContact("00000");
	}
	
}
