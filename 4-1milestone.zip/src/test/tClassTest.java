package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskclass.tClass;
import taskservice.tService;


class tClassTest {
	
		@Test
		void testtClass() {
			tClass TClass = new tClass("Alexandra", "12345", "descriptiondescriptiondescription");
			assertTrue(TClass.getName().equals("Alexandra"));
			assertTrue(TClass.getId().equals("12345"));
			assertTrue(TClass.getDescription().equals("descriptiondescriptiondescription"));
		}



		@Test
		void testTServiceAddContact() {
			tService TService = new tService();
			tClass tClass1 = new tClass("Alexandra", "12345", "descriptiondescriptiondescription");
			tClass tClass2 = new tClass("Alexandra", "11111", "descriptiondescriptiondescription");
			TService.addContact(tClass1);
			TService.addContact(tClass2);
			TService.setContactName("11111", "Chris");
			TService.setContactDescription("11111", "descriptiondescriptiondescription");
		}
		
		@Test
		void testtClassNameTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new tClass("Alexandraaaaaaaaaaaaaaaa", "12345", "descriptiondescriptiondescription");
			  });
			}
		
		@Test
		void testtClassNameNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new tClass(null, "12345", "descriptiondescriptiondescription");
			  });
			}
		
		@Test
		void testtClassIdTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new tClass("Alexandra", "123456789000", "descriptiondescriptiondescription");
			  });
			}
		
		@Test
		void testtClassIdNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new tClass("Alexandra", null, "descriptiondescriptiondescription");
			  });
			}

		@Test
		void testtClassDescriptionTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new tClass("Alexandra", "12345", "descriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescription");
			  });
			}
		
		@Test
		void testtClassDescriptionNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new tClass("Alexandra", "12345", null);
			  });
			}
		
		@Test
		void testAddNameTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tService TService = new tService();
			tClass tClass1 = new tClass("Alexandra", "11111", "descriptiondescriptiondescription");
			TService.addContact(tClass1);
			TService.setContactName("11111", "Chrissssssssssssssssssss");	
			 });
		}
		
		@Test
		void testAddNameNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tService TService = new tService();
			tClass tClass1 = new tClass("Alexandra", "11111", "descriptiondescriptiondescription");
			TService.addContact(tClass1);
			TService.setContactName("11111", null);	
			 });
		}


		
		@Test
		void testAddDescriptionTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tService TService = new tService();
			tClass tClass1 = new tClass("Alexandra", "11111", "descriptiondescriptiondescription");
			TService.addContact(tClass1);
			TService.setContactDescription("11111", "descriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescription");	
			 });
		}
		
		@Test
		void testAddDescriptionNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tService TService = new tService();
			tClass tClass1 = new tClass("Alexandra", "11111", "descriptiondescriptiondescription");
			TService.addContact(tClass1);
			TService.setContactDescription("11111", null);	
			 });
		}
	}
