package taskclass;

public class tClass {

		private String name;
		private String id;
		private String description;		
		
		public tClass(String name, String id, String description) {
			if(name == null || name.length()>20) {
				throw new IllegalArgumentException("Invalid name");
			}
			if(id == null || id.length()>10) {
				throw new IllegalArgumentException("Invalid id");
			}
			if(description == null || description.length()>50) {
				throw new IllegalArgumentException("Invalid description");
			}
			
			this.name = name;
			this.id = id;	
			this.description = description;
		}
		
		public String getName() {
			return name;
		}
		
		public String getId() {
			return id;
		}
		public String getDescription() {
			return description;
		}
		
		public Boolean setName(String name) {
			if(name == null || name.length()>20) {
				throw new IllegalArgumentException("Invalid name");
			}
			else {
				this.name = name;
				return true;
			}
		}
		
		public Boolean setdescription(String description) {
			if(description == null || description.length()>50) {
				throw new IllegalArgumentException("Invalid description");
			}
			else {
				this.description = description;
				return true;
			}
		}
		
}