package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import contact.contactClass;
import service.serviceClass;

class serviceClassTest {

	@Test
	void testserviceClassAddContact() {
		serviceClass ServiceClass = new serviceClass();
		contactClass ContactClass1 = new contactClass("Alexandra", "11111", "Meitz", "5615555555", "42 Wallaby Way, Sydney");
		contactClass ContactClass2 = new contactClass("Alexandra", "22222", "Meitz", "5615555555", "42 Wallaby Way, Sydney");
		contactClass ContactClass3 = new contactClass("Alexandra", "33333", "Meitz", "5615555555", "42 Wallaby Way, Sydney");
		contactClass ContactClass4 = new contactClass("Alexandra", "44444", "Meitz", "5615555555", "42 Wallaby Way, Sydney");
		ServiceClass.addContact(ContactClass1);
		ServiceClass.addContact(ContactClass2);
		ServiceClass.addContact(ContactClass3);
		ServiceClass.addContact(ContactClass4);
		ServiceClass.setContactName("11111", "Chris");
		ServiceClass.setContactSurname("22222", "Test");
		ServiceClass.setContactPhone("33333", "888888888");
		ServiceClass.setContactAddress("44444", "123 address");
		ServiceClass.deleteContact("11111");
		ServiceClass.deleteContact("00000");
	}
	
	
	
}
