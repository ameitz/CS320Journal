package contact;

public class contactClass {
	
		private String name;
		private String id;
		private String surname;
		private String phone;
		private String address;		
		
		public contactClass(String name, String id, String surname, 
				String phone, String address) {
			if(name == null || name.length()>10) {
				throw new IllegalArgumentException("Invalid name");
			}
			if(id == null || id.length()>10) {
				throw new IllegalArgumentException("Invalid id");
			}
			if(surname == null || surname.length()>10) {
				throw new IllegalArgumentException("Invalid surname");
			}
			if(phone == null || phone.length()>10) {
				throw new IllegalArgumentException("Invalid phone");
			}
			if(address == null || address.length()>30) {
				throw new IllegalArgumentException("Invalid address");
			}
			
			this.name = name;
			this.id = id;
			this.surname = surname;
			this.phone = phone;
			this.address = address;
		}
		
		public String getName() {
			return name;
		}
		
		public String getId() {
			return id;
		}
		
		public String getSurname() {
			return surname;
		}
		
		public String getPhone() {
			return phone;
		}
		
		public String getAddress() {
			return address;
		}
		
		public Boolean setName(String name) {
			if(name == null || name.length()>10) {
				throw new IllegalArgumentException("Invalid name");
			}
			else {
				this.name = name;
				return true;
			}
		}
		
		public Boolean setSurname(String surname) {
			if(surname == null || surname.length()>10) {
				throw new IllegalArgumentException("Invalid surname");
			}
			else {
				this.surname = surname;
				return true;
			}
		}
		
		public Boolean setPhone(String phone) {
			if(phone == null || phone.length()>10) {
				throw new IllegalArgumentException("Invalid phone");
			}
			else {
				this.phone = phone;
				return true;
			}
		}
		
		public Boolean setAddress(String address) {
			if(address == null || address.length()>30) {
				throw new IllegalArgumentException("Invalid address");
			}
			else {
				this.address = address;
				return true;
			}
		}
		
}