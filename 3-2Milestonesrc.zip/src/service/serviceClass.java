package service;
import java.util.*;
import contact.*;

public class serviceClass {
	
	private final Map<String, contactClass> contacts;
	
	public serviceClass() {
		this.contacts = new HashMap<String, contactClass>();
	}
	
	public boolean addContact(contactClass contact) {
		boolean isSuccess = false;
		
		if(!contacts.containsKey(contact.getId())) {
			contacts.put(contact.getId(), contact);
			isSuccess = true;
		}
		
		return isSuccess;
	}
	
	public boolean deleteContact(String contactId) {
		return contacts.remove(contactId) != null;
	}
	
	public contactClass getContact(String contactId) {
		return contacts.get(contactId);
	}
	
	public boolean setContactName(String contactId, String name) {
		return this.getContact(contactId).setName(name);
	}
	
	public boolean setContactSurname(String contactId, String surname) {
		return this.getContact(contactId).setSurname(surname);
	}
	
	public boolean setContactPhone(String contactId, String phone) {
		return this.getContact(contactId).setPhone(phone);
	}
	
	public boolean setContactAddress(String contactId, String address) {
		return this.getContact(contactId).setAddress(address);
	}

}